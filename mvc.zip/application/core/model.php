<?php

class Model
{

}